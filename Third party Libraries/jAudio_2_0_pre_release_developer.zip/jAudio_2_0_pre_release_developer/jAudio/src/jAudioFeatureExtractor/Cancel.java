/**
 *
 */
package jAudioFeatureExtractor;

/**
 * @author mcennis
 *
 */
public class Cancel {

	private boolean cancel = false;

	public boolean isCancel() {
		return cancel;
	}

	public void setCancel(boolean cancel) {
		this.cancel = cancel;
	}

}
